import re
import os

root = '.'
# collect modules
modules = {}
for fname in os.listdir(root):
    if not fname.endswith('.v'): continue
    path = os.path.join(root, fname)
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        txt = f.read()
    # find module declarations
    for m in re.finditer(r"module\s+(\w+)\s*(?:#\s*\([^)]*\))?\s*\((.*?)\)\s*;", txt, re.S):
        name = m.group(1)
        ports_blob = m.group(2)
        parts = []
        # split by commas but keep parentheses balance
        cur = ''
        depth = 0
        for ch in ports_blob:
            if ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
            if ch == ',' and depth == 0:
                parts.append(cur)
                cur = ''
            else:
                cur += ch
        if cur.strip(): parts.append(cur)
        ports = []
        for p in parts:
            # remove comments
            p = re.sub(r"//.*","",p)
            p = re.sub(r"/\*.*?\*/","",p,flags=re.S)
            tokens = p.strip().split()
            if not tokens: continue
            # last token may be like name or name); remove trailing symbols
            last = tokens[-1].strip()
            last = re.sub(r"[,)];$","", last)
            last = re.sub(r"[,)];$","", last)
            # also if last contains = (default), take left part
            last = last.split('=')[0].strip()
            last = last.strip(',')
            # if last is like [3:0] name, handle
            if re.match(r"^[\w$]+$", last):
                ports.append(last)
            else:
                # try find a word token in p from right
                m2 = re.search(r"([A-Za-z_]\w*)\s*(?:$|,)$", p.strip())
                if m2:
                    ports.append(m2.group(1))
        modules[name] = sorted(list(set(ports)))

# find instantiations only in top.v and check
reports = []
topfile = os.path.join(root, 'top.v')
if not os.path.exists(topfile):
    print('top.v not found in workspace')
else:
    with open(topfile, 'r', encoding='utf-8', errors='ignore') as f:
        txt = f.read()
    for inst in re.finditer(r"(\w+)\s+(\w+)\s*\((.*?)\)\s*;", txt, re.S):
        modname = inst.group(1)
        instname = inst.group(2)
        blob = inst.group(3)
        used = re.findall(r"\.(\w+)\s*\(", blob)
        if modname not in modules:
            reports.append((topfile, inst.start(), f"Module {modname} not found for instance {instname}"))
        else:
            mod_ports = modules[modname]
            for p in used:
                if p not in mod_ports:
                    reports.append((topfile, inst.start(), f"Port '{p}' not found in module {modname} (inst {instname})"))

# print summary
if not reports:
    print('No issues found')
else:
    for r in reports:
        print(f"{r[0]}:{r[1]} - {r[2]}")
    print('\nTotal issues: %d' % len(reports))
